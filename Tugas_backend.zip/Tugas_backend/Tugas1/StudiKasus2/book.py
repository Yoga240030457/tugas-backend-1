"""book.py
Definisi kelas `Book` sebagai subclass dari `LibraryItem`.

`Book` menambahkan informasi penulis dan ISBN, serta dapat
melakukan override atas kebijakan denda keterlambatan.
"""

from __future__ import annotations

from typing import Optional

from author import Author
from library_item import LibraryItem


class Book(LibraryItem):
    """Representasi buku di perpustakaan.

    Parameter
    ---------
    item_id : str
        Identitas unik item.
    title : str
        Judul buku.
    author : Author
        Penulis buku.
    isbn : str
        Kode ISBN buku.
    daily_fee : float, optional
        Tarif denda per hari; jika tidak diberikan, gunakan kebijakan default Book.
    """

    DEFAULT_DAILY_FEE: float = 1500.0  # kebijakan denda default untuk buku

    def __init__(
        self,
        item_id: str,
        title: str,
        author: Author,
        isbn: str,
        daily_fee: Optional[float] = None,
    ) -> None:
        # Gunakan tarif denda khusus Book jika tidak disediakan
        fee = daily_fee if daily_fee is not None else self.DEFAULT_DAILY_FEE
        super().__init__(item_id=item_id, title=title, daily_fee=fee)
        # Informasi penulis buku
        self.author: Author = author
        # Kode ISBN
        self.isbn: str = isbn

    def calculate_late_fee(self, days_late: int) -> float:
        """Override perhitungan denda untuk buku jika diperlukan.

        Implementasi saat ini tetap menggunakan `daily_fee` yang mungkin
        berbeda dengan item lain. Subclass ini memanggil 
        implementasi dasar melalui `super()` jika diperlukan.
        """
        # Saat ini sama seperti parent, karena `daily_fee` sudah khusus Book.
        return super().calculate_late_fee(days_late)