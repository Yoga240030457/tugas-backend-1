from datetime import date, timedelta
from author import Author
from book import Book
from library_member import LibraryMember

def tampilkan_info_buku(item: Book) -> None:
    print("Informasi Buku")
    print(f"ID: {item.item_id}")
    print(f"Judul: {item.title}")
    print(f"Penulis: {item.author}")
    print(f"ISBN: {item.isbn}")
    print(f"Sedang dipinjam: {item.is_borrowed}")
    print(f"Jatuh tempo: {item.due_date}")

def main() -> None:
    author = Author("Tere Liye")
    book = Book(item_id="B-001", title="Hafsah", author=author, isbn="978-602-XXXXXX")
    member = LibraryMember(member_id="M-100", name="Budi")
    due_date = date.today() - timedelta(days=3)
    member.borrow_item(book, due_date=due_date)
    tampilkan_info_buku(book)
    days_late = max(0, (date.today() - book.due_date).days if book.due_date else 0)
    fee = book.calculate_late_fee(days_late)
    print(f"Hari terlambat: {days_late}")
    print(f"Denda keterlambatan: {fee:.2f}")
    member.return_item(book)
    print("Status setelah dikembalikan:")
    tampilkan_info_buku(book)

if __name__ == "__main__":
    main()