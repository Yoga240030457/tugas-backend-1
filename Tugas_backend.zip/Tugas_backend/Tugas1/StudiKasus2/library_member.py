"""library_member.py
Definisi anggota perpustakaan (LibraryMember).

Kelas ini menyimpan daftar item yang dipinjam (`borrowed_items`) dan menyediakan
operasi untuk meminjam (`borrow_item`) serta mengembalikan (`return_item`) item.
"""

from __future__ import annotations

from datetime import date
from typing import List

from library_item import LibraryItem


class LibraryMember:
    """Representasi anggota perpustakaan.

    Parameter
    ---------
    member_id : str
        Identitas anggota.
    name : str
        Nama anggota.
    """

    def __init__(self, member_id: str, name: str) -> None:
        # Identitas unik anggota
        self.member_id: str = member_id
        # Nama anggota
        self.name: str = name
        # Daftar item yang sedang dipinjam anggota ini
        self.borrowed_items: List[LibraryItem] = []

    def borrow_item(self, item: LibraryItem, due_date: date) -> None:
        """Pinjam sebuah item perpustakaan.

        Aturan umum:
        - Item tidak boleh sedang dipinjam orang lain.
        - Item ditandai sebagai dipinjam oleh anggota ini.
        - Tanggal jatuh tempo disetel.
        - Item dimasukkan ke daftar `borrowed_items`.
        """
        if item.is_borrowed and item.borrowed_by is not self:
            raise ValueError("Item sedang dipinjam oleh anggota lain")

        # Tandai item dipinjam oleh anggota ini
        item.borrowed_by = self
        # Set tanggal jatuh tempo pengembalian
        item.due_date = due_date

        # Jika belum ada di daftar pinjaman anggota, tambahkan
        if item not in self.borrowed_items:
            self.borrowed_items.append(item)

    def return_item(self, item: LibraryItem) -> None:
        """Kembalikan sebuah item perpustakaan.

        Aturan umum:
        - Item harus sedang dipinjam oleh anggota ini.
        - Lepaskan keterhubungan peminjam dan hapus `due_date`.
        - Hapus item dari daftar `borrowed_items`.
        """
        if item.borrowed_by is not self:
            raise ValueError("Item tidak sedang dipinjam oleh anggota ini")

        # Lepaskan penanda peminjam dan tanggal jatuh tempo
        item.borrowed_by = None
        item.due_date = None

        # Hapus dari daftar pinjaman anggota
        try:
            self.borrowed_items.remove(item)
        except ValueError:
            # Jika item tidak ada dalam daftar (inkonsistensi), abaikan atau log
            pass