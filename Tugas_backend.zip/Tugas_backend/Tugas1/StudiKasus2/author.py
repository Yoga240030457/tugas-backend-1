"""author.py
Representasi penulis (Author) pada sistem perpustakaan.

Kelas ini mengikuti class diagram Studi Kasus 2 dan
digunakan oleh kelas `Book` untuk menyimpan informasi penulis.
"""

class Author:
    """Kelas yang merepresentasikan seorang penulis.

    Parameter
    ---------
    name : str
        Nama penulis.
    """

    def __init__(self, name: str) -> None:
        # Nama lengkap penulis
        self.name: str = name

    def __str__(self) -> str:
        """Kembalikan representasi string penulis (nama)."""
        return self.name

    def __repr__(self) -> str:
        """Representasi pengembang untuk debugging."""
        return f"Author(name={self.name!r})"