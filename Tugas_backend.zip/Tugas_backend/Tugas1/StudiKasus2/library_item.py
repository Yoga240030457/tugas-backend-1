"""library_item.py
Kelas dasar untuk item perpustakaan.

Atribut dan method mengikuti pola umum pada sistem perpustakaan,
serta disiapkan agar sesuai dengan class diagram Studi Kasus 2.

Catatan:
- `LibraryItem` mewakili entitas yang dapat dipinjam (buku, majalah, dll.).
- `borrowed_by` mereferensikan `LibraryMember` yang sedang meminjam.
- `due_date` adalah tanggal jatuh tempo pengembalian.
- `calculate_late_fee(days_late)` menghitung denda keterlambatan.
"""

from __future__ import annotations

from datetime import date
from typing import Optional


class LibraryItem:
    """Kelas dasar item perpustakaan.

    Parameter
    ---------
    item_id : str
        Identitas unik item.
    title : str
        Judul item.
    daily_fee : float
        Tarif denda per hari keterlambatan (default 1000.0).

    Atribut
    -------
    borrowed_by : Optional[LibraryMember]
        Member yang sedang meminjam item ini (None jika tidak dipinjam).
    due_date : Optional[date]
        Tanggal jatuh tempo pengembalian (None jika tidak dipinjam).
    """

    def __init__(self, item_id: str, title: str, daily_fee: float = 1000.0) -> None:
        # Identitas unik untuk setiap item
        self.item_id: str = item_id
        # Judul item
        self.title: str = title
        # Tarif denda default per hari
        self.daily_fee: float = daily_fee
        # Siapa yang meminjam item ini saat ini (None jika tersedia)
        self.borrowed_by: Optional["LibraryMember"] = None
        # Tanggal jatuh tempo pengembalian (None jika belum ditentukan)
        self.due_date: Optional[date] = None

    @property
    def is_borrowed(self) -> bool:
        """Menunjukkan apakah item sedang dipinjam."""
        return self.borrowed_by is not None

    def calculate_late_fee(self, days_late: int) -> float:
        """Hitung denda keterlambatan.

        Parameter
        ---------
        days_late : int
            Jumlah hari keterlambatan (>= 0).

        Returns
        -------
        float
            Nominal denda keterlambatan.

        Catatan
        -------
        Implementasi default menggunakan `daily_fee` sebagai tarif per hari.
        Subclass (mis. `Book`) dapat melakukan override jika kebijakannya berbeda.
        """
        if days_late <= 0:
            return 0.0
        # Denda dihitung proporsional terhadap jumlah hari terlambat
        return float(days_late) * self.daily_fee