from typing import List


class Professor:
    def __init__(self, name: str, prof_id: str):
        self.name = name
        self.prof_id = prof_id
        self.supervised_students: List = []

    def supervise(self, student) -> None:
        if len(self.supervised_students) >= 5:
            raise ValueError("Professor can supervise at most 5 students")
        self.supervised_students.append(student)

    def getSupervisedStudents(self) -> List:
        return list(self.supervised_students)