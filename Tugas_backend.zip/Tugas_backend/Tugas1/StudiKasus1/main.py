try:
    from address import Address
    from student import Student
    from professor import Professor
except ImportError:
    from .address import Address
    from .student import Student
    from .professor import Professor


def main() -> None:
    addr = Address("Jl. Merdeka No. 10", "Bandung", "Jawa Barat", "40115")

    students = [
        Student("Budi", "S001", addr, ["Matematika Dasar", "Fisika Dasar"]),
        Student("Siti", "S002", addr, ["Algoritma", "Struktur Data"]),
        Student("Andi", "S003", addr, ["Basis Data"]),
    ]

    prof = Professor("Dr. Rina", "P001")
    for s in students:
        prof.supervise(s)

    print(addr.validate())
    print(addr.outputAsLabel())

    for s in students:
        print(s.isEligibleToEnroll())
        print(s.getSeminarsTaken())

    supervised = prof.getSupervisedStudents()
    print(len(supervised))
    print([st.name for st in supervised])


if __name__ == "__main__":
    main()