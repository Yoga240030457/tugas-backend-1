from typing import List, Optional


class Student:
    def __init__(self, name: str, student_id: str, address, seminars_taken: Optional[List[str]] = None):
        self.name = name
        self.student_id = student_id
        self.address = address
        self.seminars_taken = seminars_taken or []

    def isEligibleToEnroll(self) -> bool:
        return bool(self.student_id) and self.address is not None and self.address.validate()

    def getSeminarsTaken(self) -> List[str]:
        return list(self.seminars_taken)