class Address:
    def __init__(self, street: str, city: str, province: str, postal_code: str):
        self.street = street
        self.city = city
        self.province = province
        self.postal_code = postal_code

    def validate(self) -> bool:
        if not all([self.street, self.city, self.province, self.postal_code]):
            return False
        if not self.postal_code.isdigit():
            return False
        return len(self.postal_code) == 5

    def outputAsLabel(self) -> str:
        return f"{self.street}\n{self.city}, {self.province} {self.postal_code}"